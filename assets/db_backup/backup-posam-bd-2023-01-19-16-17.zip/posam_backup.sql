#
# TABLE STRUCTURE FOR: area
#

DROP TABLE IF EXISTS `area`;

CREATE TABLE `area` (
  `area_id` int(11) NOT NULL AUTO_INCREMENT,
  `area_name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active  2=inactive',
  PRIMARY KEY (`area_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `area` (`area_id`, `area_name`, `active`) VALUES (1, 'Lucena', 1);
INSERT INTO `area` (`area_id`, `area_name`, `active`) VALUES (5, 'Bonpen', 1);
INSERT INTO `area` (`area_id`, `area_name`, `active`) VALUES (6, 'Export', 1);
INSERT INTO `area` (`area_id`, `area_name`, `active`) VALUES (8, 'Silangan', 1);
INSERT INTO `area` (`area_id`, `area_name`, `active`) VALUES (9, 'Metro Manila', 1);
INSERT INTO `area` (`area_id`, `area_name`, `active`) VALUES (12, 'South', 1);
INSERT INTO `area` (`area_id`, `area_name`, `active`) VALUES (14, 'Quezon', 1);


#
# TABLE STRUCTURE FOR: asset
#

DROP TABLE IF EXISTS `asset`;

CREATE TABLE `asset` (
  `asset_id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_type_fk` int(11) DEFAULT NULL,
  `availability_fk` int(11) DEFAULT NULL,
  `category_fk` text,
  `location_fk` int(11) DEFAULT NULL,
  `acquisition_date` date DEFAULT NULL,
  `asset_code` varchar(100) DEFAULT NULL,
  `asset_name` varchar(150) NOT NULL,
  `asset_value` decimal(12,2) NOT NULL,
  `asset_quantity` int(11) DEFAULT NULL,
  `brand` varchar(150) DEFAULT NULL,
  `description` text,
  `expiration_date` date DEFAULT NULL,
  `remark` text,
  `serial_number` varchar(150) DEFAULT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`asset_id`),
  KEY `asset_name` (`asset_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `asset` (`asset_id`, `asset_type_fk`, `availability_fk`, `category_fk`, `location_fk`, `acquisition_date`, `asset_code`, `asset_name`, `asset_value`, `asset_quantity`, `brand`, `description`, `expiration_date`, `remark`, `serial_number`, `updated_by`, `updated_date`) VALUES (5, NULL, 1, '[\"3\"]', 3, '2022-03-02', '2222', 'Equipment 2', '500.00', 1, NULL, NULL, NULL, NULL, NULL, 2, '2022-03-19 16:29:41');


#
# TABLE STRUCTURE FOR: asset_type
#

DROP TABLE IF EXISTS `asset_type`;

CREATE TABLE `asset_type` (
  `asset_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_type_code` varchar(10) NOT NULL,
  `asset_type_name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active  2=inactive',
  PRIMARY KEY (`asset_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `asset_type` (`asset_type_id`, `asset_type_code`, `asset_type_name`, `active`) VALUES (1, 'IT', 'Computer', 1);


#
# TABLE STRUCTURE FOR: availability
#

DROP TABLE IF EXISTS `availability`;

CREATE TABLE `availability` (
  `availability_id` int(11) NOT NULL AUTO_INCREMENT,
  `availability_name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active  2=inactive',
  PRIMARY KEY (`availability_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `availability` (`availability_id`, `availability_name`, `active`) VALUES (1, 'Available', 1);
INSERT INTO `availability` (`availability_id`, `availability_name`, `active`) VALUES (2, 'In other building', 1);
INSERT INTO `availability` (`availability_id`, `availability_name`, `active`) VALUES (3, 'Non Available', 1);
INSERT INTO `availability` (`availability_id`, `availability_name`, `active`) VALUES (4, 'Out for repair', 1);


#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active  2=inactive',
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `category` (`category_id`, `category_name`, `active`) VALUES (2, 'Noodles-1', 1);
INSERT INTO `category` (`category_id`, `category_name`, `active`) VALUES (3, 'Vinegar/Dressing', 1);
INSERT INTO `category` (`category_id`, `category_name`, `active`) VALUES (5, 'Sauces', 1);
INSERT INTO `category` (`category_id`, `category_name`, `active`) VALUES (10, 'Pastry Wrapper', 1);
INSERT INTO `category` (`category_id`, `category_name`, `active`) VALUES (11, 'Noodles-2', 1);


#
# TABLE STRUCTURE FOR: customer
#

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `area_fk` int(11) DEFAULT NULL,
  `customer_type_fk` int(11) DEFAULT NULL,
  `municipality_fk` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '1' COMMENT '1=Active 2=Inactive',
  `address` varchar(250) DEFAULT NULL,
  `balance` decimal(12,2) NOT NULL DEFAULT '0.00',
  `customer_code` varchar(10) DEFAULT NULL,
  `customer_name` varchar(150) NOT NULL,
  `email` varchar(250) DEFAULT NULL,
  `phone` varchar(250) DEFAULT NULL,
  `remark` text,
  `tin` varchar(50) DEFAULT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO `customer` (`customer_id`, `area_fk`, `customer_type_fk`, `municipality_fk`, `active`, `address`, `balance`, `customer_code`, `customer_name`, `email`, `phone`, `remark`, `tin`, `updated_by`, `updated_date`) VALUES (11, 1, NULL, 1, 1, NULL, '0.00', 'CUS004', 'Hasmen', 'hasmen@gmail.com', '39742364', NULL, NULL, 2, '2023-01-15 04:11:18');
INSERT INTO `customer` (`customer_id`, `area_fk`, `customer_type_fk`, `municipality_fk`, `active`, `address`, `balance`, `customer_code`, `customer_name`, `email`, `phone`, `remark`, `tin`, `updated_by`, `updated_date`) VALUES (12, 12, 1, 24, 1, 'Pamilihang Bayan', '0.00', 'CUS001', 'Alice But', 'alice@gmail.com', '09216440736', 'client particularity', '343556345', 2, '2023-01-15 04:15:16');
INSERT INTO `customer` (`customer_id`, `area_fk`, `customer_type_fk`, `municipality_fk`, `active`, `address`, `balance`, `customer_code`, `customer_name`, `email`, `phone`, `remark`, `tin`, `updated_by`, `updated_date`) VALUES (13, 8, 1, 17, 1, '74 San Raque St., Brgy. Gomez ', '0.00', 'CUS002', 'Daizy Padolina', NULL, '09391222376', NULL, '192-198-176-00', 2, '2023-01-15 19:28:21');
INSERT INTO `customer` (`customer_id`, `area_fk`, `customer_type_fk`, `municipality_fk`, `active`, `address`, `balance`, `customer_code`, `customer_name`, `email`, `phone`, `remark`, `tin`, `updated_by`, `updated_date`) VALUES (14, 1, 1, 1, 1, NULL, '0.00', 'CUS003', 'Dolores', NULL, NULL, NULL, NULL, 2, '2023-01-17 17:19:24');


#
# TABLE STRUCTURE FOR: customer_type
#

DROP TABLE IF EXISTS `customer_type`;

CREATE TABLE `customer_type` (
  `customer_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_type_code` varchar(10) NOT NULL,
  `customer_type_name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active  2=inactive',
  PRIMARY KEY (`customer_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `customer_type` (`customer_type_id`, `customer_type_code`, `customer_type_name`, `active`) VALUES (1, 'WMKT', 'Wet Market', 1);
INSERT INTO `customer_type` (`customer_type_id`, `customer_type_code`, `customer_type_name`, `active`) VALUES (3, 'SMKT', 'Supermarket', 1);
INSERT INTO `customer_type` (`customer_type_id`, `customer_type_code`, `customer_type_name`, `active`) VALUES (4, 'XCON', 'Exporter/Consolidator', 1);
INSERT INTO `customer_type` (`customer_type_id`, `customer_type_code`, `customer_type_name`, `active`) VALUES (5, 'RSNT', 'Restaurant/Diner/Cafe', 1);
INSERT INTO `customer_type` (`customer_type_id`, `customer_type_code`, `customer_type_name`, `active`) VALUES (6, 'PCTR', 'Pasalubong Center', 1);
INSERT INTO `customer_type` (`customer_type_id`, `customer_type_code`, `customer_type_name`, `active`) VALUES (7, 'FPSD', 'Fresh Produce Supplier/ Distributor', 1);
INSERT INTO `customer_type` (`customer_type_id`, `customer_type_code`, `customer_type_name`, `active`) VALUES (8, 'GMM', 'Grocery / Minimart', 1);
INSERT INTO `customer_type` (`customer_type_id`, `customer_type_code`, `customer_type_name`, `active`) VALUES (10, 'INST', 'IN-STORE/WALK-IN', 1);


#
# TABLE STRUCTURE FOR: document
#

DROP TABLE IF EXISTS `document`;

CREATE TABLE `document` (
  `document_id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_fk` int(11) DEFAULT NULL,
  `customer_fk` int(11) DEFAULT NULL,
  `employee_fk` int(11) DEFAULT NULL,
  `doc_name` varchar(100) DEFAULT NULL,
  `doc_size` int(10) DEFAULT '0',
  `doc_type` varchar(30) DEFAULT NULL,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `document` (`document_id`, `asset_fk`, `customer_fk`, `employee_fk`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (18, NULL, 14, NULL, 'DAILY_ORDER_DR_JAN_2023.xlsx', 2803, 'application/vnd.openxmlformats', '2023-01-17 17:23:07', 2);
INSERT INTO `document` (`document_id`, `asset_fk`, `customer_fk`, `employee_fk`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (19, NULL, NULL, 4, 'SM_CONTRACT_RENEWAL.pdf', 678, 'application/pdf', '2023-01-17 23:11:53', 22);
INSERT INTO `document` (`document_id`, `asset_fk`, `customer_fk`, `employee_fk`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (22, NULL, NULL, 4, 'VALID_ID.jpg', 498, 'image/jpeg', '2023-01-19 03:39:36', 22);


#
# TABLE STRUCTURE FOR: employee
#

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `employee_id` int(11) NOT NULL AUTO_INCREMENT,
  `area_fk` int(11) DEFAULT NULL,
  `employee_status_fk` int(11) DEFAULT NULL,
  `employee_type_fk` int(11) DEFAULT NULL,
  `municipality_fk` int(11) DEFAULT NULL,
  `position_fk` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '1' COMMENT '1=Active 2=Inactive',
  `address` varchar(250) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `employee_code` varchar(10) DEFAULT NULL,
  `employee_name` varchar(150) NOT NULL,
  `employment_date` date DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL COMMENT 'M=Male  F=Female  O=Other',
  `phil_health` varchar(50) DEFAULT NULL,
  `pag_ibig` varchar(50) DEFAULT NULL,
  `phone` varchar(150) DEFAULT NULL,
  `remark` text,
  `sss` varchar(50) DEFAULT NULL,
  `tin` varchar(50) DEFAULT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `employee` (`employee_id`, `area_fk`, `employee_status_fk`, `employee_type_fk`, `municipality_fk`, `position_fk`, `active`, `address`, `birthday`, `employee_code`, `employee_name`, `employment_date`, `email`, `gender`, `phil_health`, `pag_ibig`, `phone`, `remark`, `sss`, `tin`, `updated_by`, `updated_date`) VALUES (2, 14, 1, 1, 1, 1, 1, 'KM133 Diversion Road, Silangang Mayao', '1974-03-20', 'EMP002', 'Catherine Yagaya', NULL, 'newam.cathyyagaya@gmail.com', 'F', NULL, NULL, '09510548806', NULL, NULL, NULL, 22, '2023-01-17 16:54:22');
INSERT INTO `employee` (`employee_id`, `area_fk`, `employee_status_fk`, `employee_type_fk`, `municipality_fk`, `position_fk`, `active`, `address`, `birthday`, `employee_code`, `employee_name`, `employment_date`, `email`, `gender`, `phil_health`, `pag_ibig`, `phone`, `remark`, `sss`, `tin`, `updated_by`, `updated_date`) VALUES (3, 14, 1, 2, 15, 1, 1, 'Quezon St. Brgy. Daungan', '1985-09-10', 'EMP003', 'Emilyn Valancio', NULL, 'emilyn.valancio@gmail.com', 'F', NULL, NULL, '09706613461', NULL, NULL, NULL, 2, '2023-01-17 16:55:00');
INSERT INTO `employee` (`employee_id`, `area_fk`, `employee_status_fk`, `employee_type_fk`, `municipality_fk`, `position_fk`, `active`, `address`, `birthday`, `employee_code`, `employee_name`, `employment_date`, `email`, `gender`, `phil_health`, `pag_ibig`, `phone`, `remark`, `sss`, `tin`, `updated_by`, `updated_date`) VALUES (4, 14, 2, 1, 34, 1, 1, 'Langka St., Sta. Isabel Village, Abeda Community', '1966-11-25', 'EMP001', 'Eleonor Canlas', '1966-11-25', 'lareinaelenastore@gmail.com', 'F', NULL, NULL, '09176332144', NULL, '03-9899309-4', '126-630-551-000', 22, '2023-01-17 23:08:51');
INSERT INTO `employee` (`employee_id`, `area_fk`, `employee_status_fk`, `employee_type_fk`, `municipality_fk`, `position_fk`, `active`, `address`, `birthday`, `employee_code`, `employee_name`, `employment_date`, `email`, `gender`, `phil_health`, `pag_ibig`, `phone`, `remark`, `sss`, `tin`, `updated_by`, `updated_date`) VALUES (5, 14, 1, 2, 1, 1, 1, 'Brgy. Market View,', '1973-11-07', 'EMP004', 'Monilla  R. Eta', NULL, 'newam.monieremolar@gmail.com', 'F', '19-050794856-5', '11071973', '09108497905', NULL, '33-4799036-2', '208-268-100', 22, '2023-01-18 01:59:15');
INSERT INTO `employee` (`employee_id`, `area_fk`, `employee_status_fk`, `employee_type_fk`, `municipality_fk`, `position_fk`, `active`, `address`, `birthday`, `employee_code`, `employee_name`, `employment_date`, `email`, `gender`, `phil_health`, `pag_ibig`, `phone`, `remark`, `sss`, `tin`, `updated_by`, `updated_date`) VALUES (6, 1, 1, 1, 1, 1, 1, 'Mayao Silangan ', NULL, NULL, 'Mario Canon', NULL, NULL, 'M', NULL, NULL, NULL, NULL, NULL, NULL, 22, '2023-01-19 03:41:54');


#
# TABLE STRUCTURE FOR: employee_status
#

DROP TABLE IF EXISTS `employee_status`;

CREATE TABLE `employee_status` (
  `employee_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_status_code` varchar(10) NOT NULL,
  `employee_status_name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active  2=inactive',
  PRIMARY KEY (`employee_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `employee_status` (`employee_status_id`, `employee_status_code`, `employee_status_name`, `active`) VALUES (1, '1', 'Status 1', 1);
INSERT INTO `employee_status` (`employee_status_id`, `employee_status_code`, `employee_status_name`, `active`) VALUES (2, '2', 'Status 2', 1);


#
# TABLE STRUCTURE FOR: employee_type
#

DROP TABLE IF EXISTS `employee_type`;

CREATE TABLE `employee_type` (
  `employee_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_type_code` varchar(10) NOT NULL,
  `employee_type_name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active  2=inactive',
  PRIMARY KEY (`employee_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `employee_type` (`employee_type_id`, `employee_type_code`, `employee_type_name`, `active`) VALUES (1, 'REG', 'Regular', 1);
INSERT INTO `employee_type` (`employee_type_id`, `employee_type_code`, `employee_type_name`, `active`) VALUES (2, 'EXP', 'Extra / Part-Time', 1);
INSERT INTO `employee_type` (`employee_type_id`, `employee_type_code`, `employee_type_name`, `active`) VALUES (4, 'FT', 'Full-Time', 1);
INSERT INTO `employee_type` (`employee_type_id`, `employee_type_code`, `employee_type_name`, `active`) VALUES (6, 'CB', 'Contract Basis', 1);
INSERT INTO `employee_type` (`employee_type_id`, `employee_type_code`, `employee_type_name`, `active`) VALUES (7, 'TP', 'Temporary', 1);
INSERT INTO `employee_type` (`employee_type_id`, `employee_type_code`, `employee_type_name`, `active`) VALUES (8, 'SS', 'Seasonal', 1);


#
# TABLE STRUCTURE FOR: item
#

DROP TABLE IF EXISTS `item`;

CREATE TABLE `item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_fk` text,
  `unit_fk` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active 2=inactive',
  `brand` varchar(25) DEFAULT NULL,
  `item_code` varchar(25) DEFAULT NULL,
  `description` text,
  `item_name` varchar(150) NOT NULL,
  `item_price` decimal(12,2) NOT NULL,
  `price_date` date DEFAULT NULL,
  `production_level` decimal(12,2) DEFAULT NULL,
  `remark` text,
  `updated_by` int(11) NOT NULL,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO `item` (`item_id`, `category_fk`, `unit_fk`, `active`, `brand`, `item_code`, `description`, `item_name`, `item_price`, `price_date`, `production_level`, `remark`, `updated_by`, `updated_date`) VALUES (16, '[\"2\"]', 9, 1, 'La Reina Elena', 'FN001', NULL, 'Pancit Lucban', '60.00', '2023-01-15', '100.00', NULL, 22, '2023-01-15 18:40:03');
INSERT INTO `item` (`item_id`, `category_fk`, `unit_fk`, `active`, `brand`, `item_code`, `description`, `item_name`, `item_price`, `price_date`, `production_level`, `remark`, `updated_by`, `updated_date`) VALUES (17, '[\"2\"]', 9, 1, 'La Reina Elena', 'MM001', NULL, 'Mami', '43.00', '2023-01-17', NULL, NULL, 22, '2023-01-17 00:05:02');
INSERT INTO `item` (`item_id`, `category_fk`, `unit_fk`, `active`, `brand`, `item_code`, `description`, `item_name`, `item_price`, `price_date`, `production_level`, `remark`, `updated_by`, `updated_date`) VALUES (19, '[\"2\"]', 9, 1, 'La Reina Elena', 'FM001', NULL, 'Fresh Miki', '40.00', '2023-01-17', NULL, NULL, 22, '2023-01-17 23:55:30');
INSERT INTO `item` (`item_id`, `category_fk`, `unit_fk`, `active`, `brand`, `item_code`, `description`, `item_name`, `item_price`, `price_date`, `production_level`, `remark`, `updated_by`, `updated_date`) VALUES (20, '[\"2\"]', 9, 1, 'La Reina Elena', 'FM002', NULL, 'Fresh Miki', '39.00', '2023-01-18', NULL, NULL, 22, '2023-01-18 00:28:36');
INSERT INTO `item` (`item_id`, `category_fk`, `unit_fk`, `active`, `brand`, `item_code`, `description`, `item_name`, `item_price`, `price_date`, `production_level`, `remark`, `updated_by`, `updated_date`) VALUES (21, '[\"2\"]', 9, 1, 'La Reina Elena', 'LW', NULL, 'Lumpia Wrapper', '35.00', '2023-01-18', NULL, NULL, 22, '2023-01-18 01:29:57');


#
# TABLE STRUCTURE FOR: item_location
#

DROP TABLE IF EXISTS `item_location`;

CREATE TABLE `item_location` (
  `item_location_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_fk` int(11) NOT NULL,
  `location_fk` int(11) NOT NULL,
  `quantity` int(10) NOT NULL,
  `remark` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`item_location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;

INSERT INTO `item_location` (`item_location_id`, `item_fk`, `location_fk`, `quantity`, `remark`) VALUES (113, 16, 3, 210, NULL);
INSERT INTO `item_location` (`item_location_id`, `item_fk`, `location_fk`, `quantity`, `remark`) VALUES (115, 17, 7, 23, NULL);
INSERT INTO `item_location` (`item_location_id`, `item_fk`, `location_fk`, `quantity`, `remark`) VALUES (117, 19, 6, 4994, NULL);


#
# TABLE STRUCTURE FOR: location
#

DROP TABLE IF EXISTS `location`;

CREATE TABLE `location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_code` varchar(10) NOT NULL,
  `location_name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active  2=inactive',
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `location` (`location_id`, `location_code`, `location_name`, `active`) VALUES (3, 'SC', 'South', 1);
INSERT INTO `location` (`location_id`, `location_code`, `location_name`, `active`) VALUES (4, 'PROD B', 'Baked Products', 1);
INSERT INTO `location` (`location_id`, `location_code`, `location_name`, `active`) VALUES (5, 'PROD C', 'Pastry', 1);
INSERT INTO `location` (`location_id`, `location_code`, `location_name`, `active`) VALUES (6, 'PROD A', 'Fresh Products', 1);
INSERT INTO `location` (`location_id`, `location_code`, `location_name`, `active`) VALUES (7, 'SPO', 'Supply and Property Office', 1);


#
# TABLE STRUCTURE FOR: log
#

DROP TABLE IF EXISTS `log`;

CREATE TABLE `log` (
  `log_id` int(9) NOT NULL AUTO_INCREMENT,
  `asset_fk` int(11) DEFAULT NULL,
  `customer_fk` int(11) DEFAULT NULL,
  `employee_fk` int(11) DEFAULT NULL,
  `item_fk` int(11) DEFAULT NULL,
  `order_fk` int(11) DEFAULT NULL,
  `subject_fk` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `attributes` longtext NOT NULL,
  `module` varchar(100) NOT NULL,
  `remark` text,
  `updated_by` int(11) NOT NULL,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `log` (`log_id`, `asset_fk`, `customer_fk`, `employee_fk`, `item_fk`, `order_fk`, `subject_fk`, `action`, `attributes`, `module`, `remark`, `updated_by`, `updated_date`) VALUES (1, NULL, NULL, NULL, NULL, 44, 44, 'Update', 'a:2:{s:3:\"old\";a:18:{s:8:\"order_id\";s:2:\"44\";s:11:\"customer_fk\";s:2:\"13\";s:8:\"discount\";s:0:\"\";s:11:\"employee_fk\";s:1:\"2\";s:12:\"gross_amount\";s:5:\"40.00\";s:10:\"net_amount\";s:5:\"40.00\";s:10:\"order_date\";s:10:\"2023-01-18\";s:8:\"order_no\";s:7:\"2300009\";s:11:\"paid_amount\";N;s:6:\"remark\";s:0:\"\";s:14:\"service_charge\";s:1:\"0\";s:19:\"service_charge_rate\";s:1:\"0\";s:10:\"vat_charge\";s:1:\"0\";s:15:\"vat_charge_rate\";s:1:\"0\";s:10:\"updated_by\";s:2:\"22\";s:12:\"updated_date\";s:19:\"2023-01-18 00:47:10\";s:13:\"customer_name\";s:14:\"Daizy Padolina\";s:11:\"paid_status\";s:7:\"Partial\";}s:3:\"new\";a:12:{s:11:\"customer_fk\";s:2:\"13\";s:10:\"order_date\";s:10:\"2023-01-18\";s:11:\"employee_fk\";s:1:\"2\";s:12:\"gross_amount\";s:5:\"40.00\";s:10:\"net_amount\";s:5:\"40.00\";s:11:\"paid_amount\";i:0;s:19:\"service_charge_rate\";s:1:\"0\";s:14:\"service_charge\";i:0;s:15:\"vat_charge_rate\";s:1:\"0\";s:10:\"vat_charge\";i:0;s:8:\"discount\";s:0:\"\";s:10:\"updated_by\";s:1:\"2\";}}', 'Order', 'Update Order 44', 2, '2023-01-19 04:18:51');
INSERT INTO `log` (`log_id`, `asset_fk`, `customer_fk`, `employee_fk`, `item_fk`, `order_fk`, `subject_fk`, `action`, `attributes`, `module`, `remark`, `updated_by`, `updated_date`) VALUES (2, NULL, NULL, NULL, NULL, 39, 39, 'Update', 'a:2:{s:3:\"old\";a:18:{s:8:\"order_id\";s:2:\"39\";s:11:\"customer_fk\";s:2:\"13\";s:8:\"discount\";s:0:\"\";s:11:\"employee_fk\";s:1:\"3\";s:12:\"gross_amount\";s:6:\"400.00\";s:10:\"net_amount\";s:6:\"400.00\";s:10:\"order_date\";s:10:\"2023-01-17\";s:8:\"order_no\";s:7:\"2300004\";s:11:\"paid_amount\";N;s:6:\"remark\";s:0:\"\";s:14:\"service_charge\";s:1:\"0\";s:19:\"service_charge_rate\";s:1:\"0\";s:10:\"vat_charge\";s:1:\"0\";s:15:\"vat_charge_rate\";s:1:\"0\";s:10:\"updated_by\";s:1:\"2\";s:12:\"updated_date\";s:19:\"2023-01-17 16:59:37\";s:13:\"customer_name\";s:14:\"Daizy Padolina\";s:11:\"paid_status\";s:7:\"Partial\";}s:3:\"new\";a:12:{s:11:\"customer_fk\";s:2:\"13\";s:10:\"order_date\";s:10:\"2023-01-17\";s:11:\"employee_fk\";s:1:\"3\";s:12:\"gross_amount\";s:6:\"400.00\";s:10:\"net_amount\";s:6:\"400.00\";s:11:\"paid_amount\";i:0;s:19:\"service_charge_rate\";s:1:\"0\";s:14:\"service_charge\";i:0;s:15:\"vat_charge_rate\";s:1:\"0\";s:10:\"vat_charge\";i:0;s:8:\"discount\";s:0:\"\";s:10:\"updated_by\";s:1:\"2\";}}', 'Order', 'Update Order 39', 2, '2023-01-19 04:18:59');
INSERT INTO `log` (`log_id`, `asset_fk`, `customer_fk`, `employee_fk`, `item_fk`, `order_fk`, `subject_fk`, `action`, `attributes`, `module`, `remark`, `updated_by`, `updated_date`) VALUES (3, NULL, 15, NULL, NULL, NULL, 15, 'Delete', 'a:18:{s:11:\"customer_id\";s:2:\"15\";s:7:\"area_fk\";N;s:16:\"customer_type_fk\";N;s:15:\"municipality_fk\";N;s:6:\"active\";s:1:\"1\";s:7:\"address\";N;s:7:\"balance\";s:4:\"0.00\";s:13:\"customer_code\";N;s:13:\"customer_name\";s:19:\"aaaaaaaaaaaaaaaaaaa\";s:5:\"email\";N;s:5:\"phone\";N;s:6:\"remark\";N;s:3:\"tin\";N;s:10:\"updated_by\";s:1:\"2\";s:12:\"updated_date\";s:19:\"2023-01-18 20:48:51\";s:9:\"area_name\";N;s:17:\"municipality_name\";N;s:18:\"customer_type_name\";N;}', 'Customer', 'Delete Customer 15', 2, '2023-01-19 04:19:34');
INSERT INTO `log` (`log_id`, `asset_fk`, `customer_fk`, `employee_fk`, `item_fk`, `order_fk`, `subject_fk`, `action`, `attributes`, `module`, `remark`, `updated_by`, `updated_date`) VALUES (4, NULL, NULL, NULL, NULL, 40, 40, 'Update', 'a:2:{s:3:\"old\";a:18:{s:8:\"order_id\";s:2:\"40\";s:11:\"customer_fk\";s:2:\"11\";s:8:\"discount\";s:0:\"\";s:11:\"employee_fk\";s:1:\"1\";s:12:\"gross_amount\";s:6:\"400.00\";s:10:\"net_amount\";s:6:\"400.00\";s:10:\"order_date\";s:10:\"2023-01-17\";s:8:\"order_no\";s:7:\"2300005\";s:11:\"paid_amount\";s:6:\"300.00\";s:6:\"remark\";s:0:\"\";s:14:\"service_charge\";s:1:\"0\";s:19:\"service_charge_rate\";s:1:\"0\";s:10:\"vat_charge\";s:1:\"0\";s:15:\"vat_charge_rate\";s:1:\"0\";s:10:\"updated_by\";s:1:\"2\";s:12:\"updated_date\";s:19:\"2023-01-17 17:00:45\";s:13:\"customer_name\";s:6:\"Hasmen\";s:11:\"paid_status\";s:7:\"Partial\";}s:3:\"new\";a:12:{s:11:\"customer_fk\";s:2:\"11\";s:10:\"order_date\";s:10:\"2023-01-17\";s:11:\"employee_fk\";s:1:\"2\";s:12:\"gross_amount\";s:6:\"400.00\";s:10:\"net_amount\";s:6:\"400.00\";s:11:\"paid_amount\";s:6:\"300.00\";s:19:\"service_charge_rate\";s:1:\"0\";s:14:\"service_charge\";i:0;s:15:\"vat_charge_rate\";s:1:\"0\";s:10:\"vat_charge\";i:0;s:8:\"discount\";s:0:\"\";s:10:\"updated_by\";s:1:\"2\";}}', 'Order', 'Update Order 40', 2, '2023-01-19 04:20:55');
INSERT INTO `log` (`log_id`, `asset_fk`, `customer_fk`, `employee_fk`, `item_fk`, `order_fk`, `subject_fk`, `action`, `attributes`, `module`, `remark`, `updated_by`, `updated_date`) VALUES (5, NULL, NULL, 1, NULL, NULL, 1, 'Delete', 'a:24:{s:11:\"employee_id\";s:1:\"1\";s:7:\"area_fk\";s:1:\"1\";s:18:\"employee_status_fk\";s:1:\"1\";s:16:\"employee_type_fk\";s:1:\"2\";s:15:\"municipality_fk\";s:1:\"1\";s:11:\"position_fk\";s:1:\"2\";s:6:\"active\";s:1:\"1\";s:7:\"address\";s:3:\"adf\";s:8:\"birthday\";s:10:\"2023-01-10\";s:13:\"employee_code\";s:6:\"EMP001\";s:13:\"employee_name\";s:13:\"Carmen Gagnon\";s:15:\"employment_date\";s:10:\"2022-12-27\";s:5:\"email\";s:20:\"voyagine@hotmail.com\";s:6:\"gender\";s:1:\"F\";s:11:\"phil_health\";s:2:\"ph\";s:8:\"pag_ibig\";s:2:\"pi\";s:5:\"phone\";s:4:\"5555\";s:6:\"remark\";s:4:\"test\";s:3:\"sss\";s:3:\"sss\";s:3:\"tin\";s:3:\"tin\";s:10:\"updated_by\";s:1:\"2\";s:12:\"updated_date\";s:19:\"2023-01-16 02:14:13\";s:9:\"area_name\";s:6:\"Lucena\";s:17:\"municipality_name\";s:6:\"Lucena\";}', 'Employee', 'Delete Employee 1', 2, '2023-01-19 04:21:01');
INSERT INTO `log` (`log_id`, `asset_fk`, `customer_fk`, `employee_fk`, `item_fk`, `order_fk`, `subject_fk`, `action`, `attributes`, `module`, `remark`, `updated_by`, `updated_date`) VALUES (6, NULL, NULL, 5, NULL, NULL, 5, 'Update', 'a:2:{s:3:\"old\";a:24:{s:11:\"employee_id\";s:1:\"5\";s:7:\"area_fk\";s:2:\"14\";s:18:\"employee_status_fk\";s:1:\"1\";s:16:\"employee_type_fk\";s:1:\"2\";s:15:\"municipality_fk\";s:1:\"1\";s:11:\"position_fk\";s:1:\"1\";s:6:\"active\";s:1:\"1\";s:7:\"address\";s:18:\"Brgy. Market View,\";s:8:\"birthday\";s:10:\"1973-11-07\";s:13:\"employee_code\";s:6:\"EMP004\";s:13:\"employee_name\";s:15:\"Monilla  R. Eta\";s:15:\"employment_date\";N;s:5:\"email\";s:28:\"newam.monieremolar@gmail.com\";s:6:\"gender\";s:1:\"F\";s:11:\"phil_health\";s:14:\"19-050794856-5\";s:8:\"pag_ibig\";s:8:\"11071973\";s:5:\"phone\";s:11:\"09108497905\";s:6:\"remark\";N;s:3:\"sss\";s:12:\"33-4799036-2\";s:3:\"tin\";s:11:\"208-268-100\";s:10:\"updated_by\";s:1:\"2\";s:12:\"updated_date\";s:19:\"2023-01-18 01:59:15\";s:9:\"area_name\";s:6:\"Quezon\";s:17:\"municipality_name\";s:6:\"Lucena\";}s:3:\"new\";a:20:{s:6:\"active\";s:1:\"1\";s:7:\"area_fk\";s:2:\"14\";s:16:\"employee_type_fk\";s:1:\"2\";s:18:\"employee_status_fk\";s:1:\"1\";s:15:\"municipality_fk\";s:1:\"1\";s:11:\"position_fk\";s:1:\"1\";s:7:\"address\";s:18:\"Brgy. Market View,\";s:8:\"birthday\";s:10:\"1973-11-07\";s:5:\"email\";s:32:\"newam.monieremolar@gmail.com.com\";s:13:\"employee_name\";s:15:\"Monilla  R. Eta\";s:13:\"employee_code\";s:6:\"EMP004\";s:15:\"employment_date\";N;s:6:\"gender\";s:1:\"F\";s:8:\"pag_ibig\";s:8:\"11071973\";s:11:\"phil_health\";s:14:\"19-050794856-5\";s:5:\"phone\";s:11:\"09108497905\";s:6:\"remark\";N;s:3:\"sss\";s:12:\"33-4799036-2\";s:3:\"tin\";s:11:\"208-268-100\";s:10:\"updated_by\";s:2:\"22\";}}', 'Employee', 'Update Employee 5', 22, '2023-01-19 16:12:22');
INSERT INTO `log` (`log_id`, `asset_fk`, `customer_fk`, `employee_fk`, `item_fk`, `order_fk`, `subject_fk`, `action`, `attributes`, `module`, `remark`, `updated_by`, `updated_date`) VALUES (7, NULL, NULL, 5, NULL, NULL, 5, 'Update', 'a:2:{s:3:\"old\";a:24:{s:11:\"employee_id\";s:1:\"5\";s:7:\"area_fk\";s:2:\"14\";s:18:\"employee_status_fk\";s:1:\"1\";s:16:\"employee_type_fk\";s:1:\"2\";s:15:\"municipality_fk\";s:1:\"1\";s:11:\"position_fk\";s:1:\"1\";s:6:\"active\";s:1:\"1\";s:7:\"address\";s:18:\"Brgy. Market View,\";s:8:\"birthday\";s:10:\"1973-11-07\";s:13:\"employee_code\";s:6:\"EMP004\";s:13:\"employee_name\";s:15:\"Monilla  R. Eta\";s:15:\"employment_date\";N;s:5:\"email\";s:32:\"newam.monieremolar@gmail.com.com\";s:6:\"gender\";s:1:\"F\";s:11:\"phil_health\";s:14:\"19-050794856-5\";s:8:\"pag_ibig\";s:8:\"11071973\";s:5:\"phone\";s:11:\"09108497905\";s:6:\"remark\";N;s:3:\"sss\";s:12:\"33-4799036-2\";s:3:\"tin\";s:11:\"208-268-100\";s:10:\"updated_by\";s:2:\"22\";s:12:\"updated_date\";s:19:\"2023-01-18 01:59:15\";s:9:\"area_name\";s:6:\"Quezon\";s:17:\"municipality_name\";s:6:\"Lucena\";}s:3:\"new\";a:20:{s:6:\"active\";s:1:\"1\";s:7:\"area_fk\";s:2:\"14\";s:16:\"employee_type_fk\";s:1:\"2\";s:18:\"employee_status_fk\";s:1:\"1\";s:15:\"municipality_fk\";s:1:\"1\";s:11:\"position_fk\";s:1:\"1\";s:7:\"address\";s:18:\"Brgy. Market View,\";s:8:\"birthday\";s:10:\"1973-11-07\";s:5:\"email\";s:28:\"newam.monieremolar@gmail.com\";s:13:\"employee_name\";s:15:\"Monilla  R. Eta\";s:13:\"employee_code\";s:6:\"EMP004\";s:15:\"employment_date\";N;s:6:\"gender\";s:1:\"F\";s:8:\"pag_ibig\";s:8:\"11071973\";s:11:\"phil_health\";s:14:\"19-050794856-5\";s:5:\"phone\";s:11:\"09108497905\";s:6:\"remark\";N;s:3:\"sss\";s:12:\"33-4799036-2\";s:3:\"tin\";s:11:\"208-268-100\";s:10:\"updated_by\";s:2:\"22\";}}', 'Employee', 'Update Employee 5', 22, '2023-01-19 16:12:39');


#
# TABLE STRUCTURE FOR: maintenance
#

DROP TABLE IF EXISTS `maintenance`;

CREATE TABLE `maintenance` (
  `maintenance_id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_fk` int(11) NOT NULL,
  `maintenance_type_fk` int(11) NOT NULL,
  `cost` decimal(12,2) NOT NULL,
  `description` text,
  `maintenance_date` date DEFAULT NULL,
  `maintenance_name` varchar(150) NOT NULL,
  `remark` text,
  `updated_by` int(11) NOT NULL,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`maintenance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `maintenance` (`maintenance_id`, `asset_fk`, `maintenance_type_fk`, `cost`, `description`, `maintenance_date`, `maintenance_name`, `remark`, `updated_by`, `updated_date`) VALUES (11, 5, 9, '5555.00', 'a', '2023-01-16', 'dfdfxxxxxxxxxxxxxxxxxx', 'b', 2, '2023-01-16 00:53:36');


#
# TABLE STRUCTURE FOR: maintenance_type
#

DROP TABLE IF EXISTS `maintenance_type`;

CREATE TABLE `maintenance_type` (
  `maintenance_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `maintenance_type_code` varchar(10) NOT NULL,
  `maintenance_type_name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active  2=inactive',
  PRIMARY KEY (`maintenance_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `maintenance_type` (`maintenance_type_id`, `maintenance_type_code`, `maintenance_type_name`, `active`) VALUES (6, 'MAINTAIN', 'Maintenance annual', 1);
INSERT INTO `maintenance_type` (`maintenance_type_id`, `maintenance_type_code`, `maintenance_type_name`, `active`) VALUES (7, 'REPAIR', 'Repair the asset', 1);
INSERT INTO `maintenance_type` (`maintenance_type_id`, `maintenance_type_code`, `maintenance_type_name`, `active`) VALUES (8, 'CHANGE', 'Change for a new asset', 1);
INSERT INTO `maintenance_type` (`maintenance_type_id`, `maintenance_type_code`, `maintenance_type_name`, `active`) VALUES (9, 'RENEWAL', 'Renewal', 1);


#
# TABLE STRUCTURE FOR: movement
#

DROP TABLE IF EXISTS `movement`;

CREATE TABLE `movement` (
  `movement_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_fk` int(11) DEFAULT NULL,
  `item_location_fk` int(11) DEFAULT NULL,
  `date_movement` date NOT NULL,
  `order_amount` varchar(255) DEFAULT NULL,
  `order_rate` varchar(255) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `remark` varchar(100) DEFAULT NULL,
  `type_movement` tinyint(1) DEFAULT NULL COMMENT '1=In  2=Out',
  `updated_by` int(11) NOT NULL,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`movement_id`)
) ENGINE=InnoDB AUTO_INCREMENT=526 DEFAULT CHARSET=utf8;

INSERT INTO `movement` (`movement_id`, `order_fk`, `item_location_fk`, `date_movement`, `order_amount`, `order_rate`, `quantity`, `remark`, `type_movement`, `updated_by`, `updated_date`) VALUES (506, 38, 113, '2023-01-17', '400.00', '40.00', 10, 'Order ', NULL, 2, '2023-01-17 16:59:04');
INSERT INTO `movement` (`movement_id`, `order_fk`, `item_location_fk`, `date_movement`, `order_amount`, `order_rate`, `quantity`, `remark`, `type_movement`, `updated_by`, `updated_date`) VALUES (507, 38, 115, '2023-01-17', '50.00', '50.00', 1, 'Order ', NULL, 2, '2023-01-17 16:59:04');
INSERT INTO `movement` (`movement_id`, `order_fk`, `item_location_fk`, `date_movement`, `order_amount`, `order_rate`, `quantity`, `remark`, `type_movement`, `updated_by`, `updated_date`) VALUES (514, NULL, 113, '2023-01-17', NULL, NULL, 50, '', 2, 2, '2023-01-17 18:31:29');
INSERT INTO `movement` (`movement_id`, `order_fk`, `item_location_fk`, `date_movement`, `order_amount`, `order_rate`, `quantity`, `remark`, `type_movement`, `updated_by`, `updated_date`) VALUES (518, 43, 117, '2023-01-18', '4000.00', '40.00', 100, 'Order ', NULL, 22, '2023-01-18 00:43:57');
INSERT INTO `movement` (`movement_id`, `order_fk`, `item_location_fk`, `date_movement`, `order_amount`, `order_rate`, `quantity`, `remark`, `type_movement`, `updated_by`, `updated_date`) VALUES (519, NULL, 117, '2023-01-18', NULL, NULL, 100, '', 1, 20, '2023-01-18 00:44:36');
INSERT INTO `movement` (`movement_id`, `order_fk`, `item_location_fk`, `date_movement`, `order_amount`, `order_rate`, `quantity`, `remark`, `type_movement`, `updated_by`, `updated_date`) VALUES (521, NULL, 117, '2023-01-18', NULL, NULL, 4000, '', 1, 22, '2023-01-18 00:48:56');
INSERT INTO `movement` (`movement_id`, `order_fk`, `item_location_fk`, `date_movement`, `order_amount`, `order_rate`, `quantity`, `remark`, `type_movement`, `updated_by`, `updated_date`) VALUES (522, NULL, 117, '2023-01-18', NULL, NULL, 5, 'FOR GARBAGGE COLLECTOR', 2, 22, '2023-01-18 00:50:52');
INSERT INTO `movement` (`movement_id`, `order_fk`, `item_location_fk`, `date_movement`, `order_amount`, `order_rate`, `quantity`, `remark`, `type_movement`, `updated_by`, `updated_date`) VALUES (523, 44, 117, '2023-01-19', '40.00', '40.00', 1, 'Order ', NULL, 2, '2023-01-19 04:18:51');
INSERT INTO `movement` (`movement_id`, `order_fk`, `item_location_fk`, `date_movement`, `order_amount`, `order_rate`, `quantity`, `remark`, `type_movement`, `updated_by`, `updated_date`) VALUES (524, 39, 113, '2023-01-19', '400.00', '40.00', 10, 'Order ', NULL, 2, '2023-01-19 04:18:59');
INSERT INTO `movement` (`movement_id`, `order_fk`, `item_location_fk`, `date_movement`, `order_amount`, `order_rate`, `quantity`, `remark`, `type_movement`, `updated_by`, `updated_date`) VALUES (525, 40, 113, '2023-01-19', '400.00', '40.00', 10, 'Order ', NULL, 2, '2023-01-19 04:20:55');


#
# TABLE STRUCTURE FOR: municipality
#

DROP TABLE IF EXISTS `municipality`;

CREATE TABLE `municipality` (
  `municipality_id` int(11) NOT NULL AUTO_INCREMENT,
  `municipality_name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active  2=inactive',
  PRIMARY KEY (`municipality_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (1, 'Lucena', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (5, 'South', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (6, 'Candelaria', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (8, 'Catanauan', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (9, 'Catanauan', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (10, 'Gen. Luna', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (11, 'Macalelon', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (12, 'Unisan', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (13, 'Agdangan', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (14, 'Burgos', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (15, 'Pagbilao', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (16, 'Gumaca', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (17, 'Lopez', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (18, 'Guinyangan', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (19, 'Calauag', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (20, 'Sain', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (21, 'Atimonan', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (22, 'Macalelon', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (23, 'Unisan', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (24, 'Sariaya', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (25, 'Candelaria', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (26, 'Carmona', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (27, 'San Juan', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (28, 'Pasay', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (29, 'Balintawak', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (30, 'Manila', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (31, 'Pasig', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (32, 'Delmonte Bulacan', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (33, 'Calamba', 1);
INSERT INTO `municipality` (`municipality_id`, `municipality_name`, `active`) VALUES (34, 'Tayabas', 1);


#
# TABLE STRUCTURE FOR: orders
#

DROP TABLE IF EXISTS `orders`;

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_fk` int(11) DEFAULT NULL,
  `discount` varchar(255) NOT NULL,
  `employee_fk` int(11) DEFAULT NULL,
  `gross_amount` varchar(255) NOT NULL,
  `net_amount` varchar(255) NOT NULL,
  `order_date` date DEFAULT NULL,
  `order_no` varchar(255) NOT NULL,
  `paid_amount` decimal(12,2) DEFAULT NULL,
  `remark` varchar(255) NOT NULL,
  `service_charge` varchar(255) NOT NULL,
  `service_charge_rate` varchar(255) NOT NULL,
  `vat_charge` varchar(255) NOT NULL,
  `vat_charge_rate` varchar(255) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

INSERT INTO `orders` (`order_id`, `customer_fk`, `discount`, `employee_fk`, `gross_amount`, `net_amount`, `order_date`, `order_no`, `paid_amount`, `remark`, `service_charge`, `service_charge_rate`, `vat_charge`, `vat_charge_rate`, `updated_by`, `updated_date`) VALUES (38, 12, '', 2, '450.00', '450.00', '2023-01-17', '2300003', '450.00', '', '0', '0', '0', '0', 2, '2023-01-17 16:58:54');
INSERT INTO `orders` (`order_id`, `customer_fk`, `discount`, `employee_fk`, `gross_amount`, `net_amount`, `order_date`, `order_no`, `paid_amount`, `remark`, `service_charge`, `service_charge_rate`, `vat_charge`, `vat_charge_rate`, `updated_by`, `updated_date`) VALUES (39, 13, '', 3, '400.00', '400.00', '2023-01-17', '2300004', '0.00', '', '0', '0', '0', '0', 2, '2023-01-17 16:59:37');
INSERT INTO `orders` (`order_id`, `customer_fk`, `discount`, `employee_fk`, `gross_amount`, `net_amount`, `order_date`, `order_no`, `paid_amount`, `remark`, `service_charge`, `service_charge_rate`, `vat_charge`, `vat_charge_rate`, `updated_by`, `updated_date`) VALUES (40, 11, '', 2, '400.00', '400.00', '2023-01-17', '2300005', '300.00', '', '0', '0', '0', '0', 2, '2023-01-17 17:00:45');
INSERT INTO `orders` (`order_id`, `customer_fk`, `discount`, `employee_fk`, `gross_amount`, `net_amount`, `order_date`, `order_no`, `paid_amount`, `remark`, `service_charge`, `service_charge_rate`, `vat_charge`, `vat_charge_rate`, `updated_by`, `updated_date`) VALUES (43, 13, '', 3, '4000.00', '4000.00', '2023-01-18', '2300008', '0.00', '', '0', '0', '0', '0', 22, '2023-01-18 00:42:58');
INSERT INTO `orders` (`order_id`, `customer_fk`, `discount`, `employee_fk`, `gross_amount`, `net_amount`, `order_date`, `order_no`, `paid_amount`, `remark`, `service_charge`, `service_charge_rate`, `vat_charge`, `vat_charge_rate`, `updated_by`, `updated_date`) VALUES (44, 13, '', 2, '40.00', '40.00', '2023-01-18', '2300009', '0.00', '', '0', '0', '0', '0', 2, '2023-01-18 00:47:10');


#
# TABLE STRUCTURE FOR: organization
#

DROP TABLE IF EXISTS `organization`;

CREATE TABLE `organization` (
  `organization_id` int(11) NOT NULL AUTO_INCREMENT,
  `organization_name` varchar(100) NOT NULL,
  `service_charge_value` tinyint(3) NOT NULL,
  `vat_charge_value` tinyint(3) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `country` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `currency` char(3) NOT NULL,
  PRIMARY KEY (`organization_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `organization` (`organization_id`, `organization_name`, `service_charge_value`, `vat_charge_value`, `address`, `phone`, `country`, `message`, `currency`) VALUES (1, 'Amstature Foods', 0, 0, 'My Adress', '', 'Philippines', 'hello everyone one', 'PHP');


#
# TABLE STRUCTURE FOR: position
#

DROP TABLE IF EXISTS `position`;

CREATE TABLE `position` (
  `position_id` int(11) NOT NULL AUTO_INCREMENT,
  `position_code` varchar(10) NOT NULL,
  `position_name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active  2=inactive',
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `position` (`position_id`, `position_code`, `position_name`, `active`) VALUES (1, 'ADO', 'Admin  Officer', 1);
INSERT INTO `position` (`position_id`, `position_code`, `position_name`, `active`) VALUES (2, 'DLC', 'Delivery Crew', 1);
INSERT INTO `position` (`position_id`, `position_code`, `position_name`, `active`) VALUES (4, 'PDC', 'Production Crew', 1);
INSERT INTO `position` (`position_id`, `position_code`, `position_name`, `active`) VALUES (5, 'UTC', 'Utility Crew', 1);
INSERT INTO `position` (`position_id`, `position_code`, `position_name`, `active`) VALUES (6, 'HSO', 'Health & Safety Officer', 1);
INSERT INTO `position` (`position_id`, `position_code`, `position_name`, `active`) VALUES (7, 'ADS', 'Admin Assistant', 1);
INSERT INTO `position` (`position_id`, `position_code`, `position_name`, `active`) VALUES (8, 'GMG', 'General Manager', 1);
INSERT INTO `position` (`position_id`, `position_code`, `position_name`, `active`) VALUES (9, 'OMG', 'Operation Manager', 1);


#
# TABLE STRUCTURE FOR: profile
#

DROP TABLE IF EXISTS `profile`;

CREATE TABLE `profile` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_name` varchar(100) NOT NULL,
  `permission` text NOT NULL,
  PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `profile` (`profile_id`, `profile_name`, `permission`) VALUES (1, 'Administrator', 'a:36:{i:0;s:10:\"createUser\";i:1;s:10:\"updateUser\";i:2;s:8:\"viewUser\";i:3;s:10:\"deleteUser\";i:4;s:11:\"createGroup\";i:5;s:11:\"updateGroup\";i:6;s:9:\"viewGroup\";i:7;s:11:\"deleteGroup\";i:8;s:11:\"createBrand\";i:9;s:11:\"updateBrand\";i:10;s:9:\"viewBrand\";i:11;s:11:\"deleteBrand\";i:12;s:14:\"createCategory\";i:13;s:14:\"updateCategory\";i:14;s:12:\"viewCategory\";i:15;s:14:\"deleteCategory\";i:16;s:11:\"createStore\";i:17;s:11:\"updateStore\";i:18;s:9:\"viewStore\";i:19;s:11:\"deleteStore\";i:20;s:15:\"createAttribute\";i:21;s:15:\"updateAttribute\";i:22;s:13:\"viewAttribute\";i:23;s:15:\"deleteAttribute\";i:24;s:13:\"createProduct\";i:25;s:13:\"updateProduct\";i:26;s:11:\"viewProduct\";i:27;s:13:\"deleteProduct\";i:28;s:11:\"createOrder\";i:29;s:11:\"updateOrder\";i:30;s:9:\"viewOrder\";i:31;s:11:\"deleteOrder\";i:32;s:11:\"viewReports\";i:33;s:13:\"updateCompany\";i:34;s:11:\"viewProfile\";i:35;s:13:\"updateSetting\";}');
INSERT INTO `profile` (`profile_id`, `profile_name`, `permission`) VALUES (7, 'reader', 'a:19:{i:0;s:8:\"viewItem\";i:1;s:9:\"viewOrder\";i:2;s:12:\"viewCustomer\";i:3;s:8:\"viewArea\";i:4;s:16:\"viewMunicipality\";i:5;s:9:\"viewAsset\";i:6;s:16:\"viewAvailability\";i:7;s:12:\"viewDocument\";i:8;s:15:\"viewMaintenance\";i:9;s:19:\"viewMaintenanceType\";i:10;s:12:\"viewCategory\";i:11;s:12:\"viewLocation\";i:12;s:8:\"viewUnit\";i:13;s:12:\"viewMovement\";i:14;s:13:\"viewDashboard\";i:15;s:10:\"viewReport\";i:16;s:11:\"viewProfile\";i:17;s:8:\"viewUser\";i:18;s:16:\"viewOrganization\";}');
INSERT INTO `profile` (`profile_id`, `profile_name`, `permission`) VALUES (11, 'superadmin', 'a:84:{i:0;s:16:\"createConsumable\";i:1;s:16:\"updateConsumable\";i:2;s:14:\"viewConsumable\";i:3;s:16:\"deleteConsumable\";i:4;s:13:\"createMeasure\";i:5;s:13:\"updateMeasure\";i:6;s:11:\"viewMeasure\";i:7;s:13:\"deleteMeasure\";i:8;s:15:\"createEquipment\";i:9;s:15:\"updateEquipment\";i:10;s:13:\"viewEquipment\";i:11;s:15:\"deleteEquipment\";i:12;s:18:\"createAvailability\";i:13;s:18:\"updateAvailability\";i:14;s:16:\"viewAvailability\";i:15;s:18:\"deleteAvailability\";i:16;s:20:\"createEquipmentClass\";i:17;s:20:\"updateEquipmentClass\";i:18;s:18:\"viewEquipmentClass\";i:19;s:20:\"deleteEquipmentClass\";i:20;s:17:\"createMaintenance\";i:21;s:17:\"updateMaintenance\";i:22;s:15:\"viewMaintenance\";i:23;s:17:\"deleteMaintenance\";i:24;s:21:\"createMaintenanceType\";i:25;s:21:\"updateMaintenanceType\";i:26;s:19:\"viewMaintenanceType\";i:27;s:21:\"deleteMaintenanceType\";i:28;s:12:\"createStatus\";i:29;s:12:\"updateStatus\";i:30;s:10:\"viewStatus\";i:31;s:12:\"deleteStatus\";i:32;s:14:\"createResource\";i:33;s:14:\"updateResource\";i:34;s:12:\"viewResource\";i:35;s:14:\"deleteResource\";i:36;s:18:\"createResourceType\";i:37;s:18:\"updateResourceType\";i:38;s:16:\"viewResourceType\";i:39;s:18:\"deleteResourceType\";i:40;s:16:\"createCompetence\";i:41;s:16:\"updateCompetence\";i:42;s:14:\"viewCompetence\";i:43;s:16:\"deleteCompetence\";i:44;s:9:\"createJob\";i:45;s:9:\"updateJob\";i:46;s:7:\"viewJob\";i:47;s:9:\"deleteJob\";i:48;s:11:\"createState\";i:49;s:11:\"updateState\";i:50;s:9:\"viewState\";i:51;s:11:\"deleteState\";i:52;s:14:\"createCategory\";i:53;s:14:\"updateCategory\";i:54;s:12:\"viewCategory\";i:55;s:14:\"deleteCategory\";i:56;s:14:\"createLocation\";i:57;s:14:\"updateLocation\";i:58;s:12:\"viewLocation\";i:59;s:14:\"deleteLocation\";i:60;s:14:\"createDocument\";i:61;s:14:\"updateDocument\";i:62;s:12:\"viewDocument\";i:63;s:14:\"deleteDocument\";i:64;s:14:\"createMovement\";i:65;s:14:\"updateMovement\";i:66;s:12:\"viewMovement\";i:67;s:14:\"deleteMovement\";i:68;s:13:\"viewDashboard\";i:69;s:10:\"viewReport\";i:70;s:13:\"createProfile\";i:71;s:13:\"updateProfile\";i:72;s:11:\"viewProfile\";i:73;s:13:\"deleteProfile\";i:74;s:10:\"createUser\";i:75;s:10:\"updateUser\";i:76;s:8:\"viewUser\";i:77;s:10:\"deleteUser\";i:78;s:18:\"createOrganization\";i:79;s:18:\"updateOrganization\";i:80;s:16:\"viewOrganization\";i:81;s:18:\"deleteOrganization\";i:82;s:12:\"updateSystem\";i:83;s:13:\"updateSetting\";}');
INSERT INTO `profile` (`profile_id`, `profile_name`, `permission`) VALUES (12, 'admin', 'a:96:{i:0;s:10:\"createItem\";i:1;s:10:\"updateItem\";i:2;s:8:\"viewItem\";i:3;s:10:\"deleteItem\";i:4;s:11:\"createOrder\";i:5;s:11:\"updateOrder\";i:6;s:9:\"viewOrder\";i:7;s:11:\"deleteOrder\";i:8;s:14:\"createCustomer\";i:9;s:14:\"updateCustomer\";i:10;s:12:\"viewCustomer\";i:11;s:14:\"deleteCustomer\";i:12;s:18:\"createCustomerType\";i:13;s:18:\"updateCustomerType\";i:14;s:16:\"viewCustomerType\";i:15;s:18:\"deleteCustomerType\";i:16;s:10:\"createArea\";i:17;s:10:\"updateArea\";i:18;s:8:\"viewArea\";i:19;s:10:\"deleteArea\";i:20;s:18:\"createMunicipality\";i:21;s:18:\"updateMunicipality\";i:22;s:16:\"viewMunicipality\";i:23;s:18:\"deleteMunicipality\";i:24;s:11:\"createAsset\";i:25;s:11:\"updateAsset\";i:26;s:9:\"viewAsset\";i:27;s:11:\"deleteAsset\";i:28;s:15:\"createAssetType\";i:29;s:15:\"updateAssetType\";i:30;s:13:\"viewAssetType\";i:31;s:15:\"deleteAssetType\";i:32;s:18:\"createAvailability\";i:33;s:18:\"updateAvailability\";i:34;s:16:\"viewAvailability\";i:35;s:18:\"deleteAvailability\";i:36;s:14:\"createDocument\";i:37;s:14:\"updateDocument\";i:38;s:12:\"viewDocument\";i:39;s:14:\"deleteDocument\";i:40;s:17:\"createMaintenance\";i:41;s:17:\"updateMaintenance\";i:42;s:15:\"viewMaintenance\";i:43;s:17:\"deleteMaintenance\";i:44;s:21:\"createMaintenanceType\";i:45;s:21:\"updateMaintenanceType\";i:46;s:19:\"viewMaintenanceType\";i:47;s:21:\"deleteMaintenanceType\";i:48;s:14:\"createEmployee\";i:49;s:14:\"updateEmployee\";i:50;s:12:\"viewEmployee\";i:51;s:14:\"deleteEmployee\";i:52;s:18:\"createEmployeeType\";i:53;s:18:\"updateEmployeeType\";i:54;s:16:\"viewEmployeeType\";i:55;s:18:\"deleteEmployeeType\";i:56;s:20:\"createEmployeeStatus\";i:57;s:20:\"updateEmployeeStatus\";i:58;s:18:\"viewEmployeeStatus\";i:59;s:20:\"deleteEmployeeStatus\";i:60;s:14:\"createPosition\";i:61;s:14:\"updatePosition\";i:62;s:12:\"viewPosition\";i:63;s:14:\"deletePosition\";i:64;s:14:\"createCategory\";i:65;s:14:\"updateCategory\";i:66;s:12:\"viewCategory\";i:67;s:14:\"deleteCategory\";i:68;s:14:\"createLocation\";i:69;s:14:\"updateLocation\";i:70;s:12:\"viewLocation\";i:71;s:14:\"deleteLocation\";i:72;s:10:\"createUnit\";i:73;s:10:\"updateUnit\";i:74;s:8:\"viewUnit\";i:75;s:10:\"deleteUnit\";i:76;s:14:\"createMovement\";i:77;s:14:\"updateMovement\";i:78;s:12:\"viewMovement\";i:79;s:14:\"deleteMovement\";i:80;s:13:\"viewDashboard\";i:81;s:10:\"viewReport\";i:82;s:13:\"createProfile\";i:83;s:13:\"updateProfile\";i:84;s:11:\"viewProfile\";i:85;s:13:\"deleteProfile\";i:86;s:10:\"createUser\";i:87;s:10:\"updateUser\";i:88;s:8:\"viewUser\";i:89;s:10:\"deleteUser\";i:90;s:18:\"createOrganization\";i:91;s:18:\"updateOrganization\";i:92;s:16:\"viewOrganization\";i:93;s:18:\"deleteOrganization\";i:94;s:12:\"updateSystem\";i:95;s:13:\"updateSetting\";}');


#
# TABLE STRUCTURE FOR: report
#

DROP TABLE IF EXISTS `report`;

CREATE TABLE `report` (
  `report_id` int(11) NOT NULL AUTO_INCREMENT,
  `report_code` char(5) NOT NULL,
  `report_desc` varchar(200) DEFAULT NULL,
  `report_form` varchar(100) NOT NULL,
  `report_title` varchar(100) NOT NULL,
  `report_for` varchar(15) NOT NULL,
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO `report` (`report_id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_for`) VALUES (1, 'REP01', 'List of items', '/application/controllers/Repor01.php', 'List of items', 'report');
INSERT INTO `report` (`report_id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_for`) VALUES (2, 'REP02', 'List of Assets', '/application/controllers/report02.php', 'List of Assets', 'report');
INSERT INTO `report` (`report_id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_for`) VALUES (5, 'REP81', 'Print a specific item', '/application/controllers/report_item.php', 'item', 'none');
INSERT INTO `report` (`report_id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_for`) VALUES (6, 'REP82', 'Print a specific resource', '/application/controllers/report_resource.php', 'resource', 'none');
INSERT INTO `report` (`report_id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_for`) VALUES (7, 'REP83', 'Print a specific order', '/application/controllers/report_order.php', 'Order', 'none');
INSERT INTO `report` (`report_id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_for`) VALUES (8, 'REP84', 'Print a specific asset', '/application/controllers/report_asset.php', 'Asset', 'none');
INSERT INTO `report` (`report_id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_for`) VALUES (9, 'REP85', 'Print a specific setting', '/application/controllers/report_setting.php', 'Setting', 'none');
INSERT INTO `report` (`report_id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_for`) VALUES (10, 'REP03', 'List of Orders', '/application/controllers/report03.php', 'List of Orders', 'report');
INSERT INTO `report` (`report_id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_for`) VALUES (11, 'REP86', 'Print a specific customer', '/application/controllers/report_customer.php', 'Customer', 'none');
INSERT INTO `report` (`report_id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_for`) VALUES (12, 'REP87', 'Print a specific employee', '/application/controllers/report_employee.php', 'Employee', 'none');
INSERT INTO `report` (`report_id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_for`) VALUES (13, 'REP04', 'List of Customers', '/application/controllers/report04.php', 'List of customers', 'report');
INSERT INTO `report` (`report_id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_for`) VALUES (14, 'REP05', 'List of Employees', '/application/controllers/report05.php', 'List of Employees', 'report');
INSERT INTO `report` (`report_id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_for`) VALUES (15, 'REP88', 'Print a specific order', '/application/controllers/report_order.php', 'Order Slip', 'none');


#
# TABLE STRUCTURE FOR: unit
#

DROP TABLE IF EXISTS `unit`;

CREATE TABLE `unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active  2=inactive',
  PRIMARY KEY (`unit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO `unit` (`unit_id`, `unit_name`, `active`) VALUES (9, 'KG', 1);
INSERT INTO `unit` (`unit_id`, `unit_name`, `active`) VALUES (10, 'CTN', 1);
INSERT INTO `unit` (`unit_id`, `unit_name`, `active`) VALUES (11, 'BDL', 1);
INSERT INTO `unit` (`unit_id`, `unit_name`, `active`) VALUES (12, 'LITER', 1);
INSERT INTO `unit` (`unit_id`, `unit_name`, `active`) VALUES (13, 'SCK', 1);
INSERT INTO `unit` (`unit_id`, `unit_name`, `active`) VALUES (23, 'GAL', 1);
INSERT INTO `unit` (`unit_id`, `unit_name`, `active`) VALUES (24, 'PCS', 1);
INSERT INTO `unit` (`unit_id`, `unit_name`, `active`) VALUES (25, 'BTL', 1);
INSERT INTO `unit` (`unit_id`, `unit_name`, `active`) VALUES (26, 'PACKS', 1);


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_fk` int(11) NOT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) NOT NULL,
  `remark` text,
  `phone` varchar(255) DEFAULT NULL,
  `active` int(11) NOT NULL COMMENT '1=active  2=inactive',
  `updated_by` int(11) DEFAULT NULL,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO `user` (`user_id`, `profile_fk`, `employee_id`, `username`, `password`, `email`, `user_name`, `remark`, `phone`, `active`, `updated_by`, `updated_date`) VALUES (2, 12, 7, 'voyagine', '$2y$10$bQqR.jmqPDZNTfp3I7woBeUBcGHHAWdMRwnXgkxaqteIamdgN0vgW', 'voyagine@hotmail.com', 'Carmen Gagnon', NULL, '5149836594', 0, 18, '2019-09-17 12:37:09');
INSERT INTO `user` (`user_id`, `profile_fk`, `employee_id`, `username`, `password`, `email`, `user_name`, `remark`, `phone`, `active`, `updated_by`, `updated_date`) VALUES (19, 7, NULL, 'testing', '', 'test@tes.com', 'testxxxxxx', 'aaaaaaaaaaaaaaaaaaaa', '343333', 1, 2, '0000-00-00 00:00:00');
INSERT INTO `user` (`user_id`, `profile_fk`, `employee_id`, `username`, `password`, `email`, `user_name`, `remark`, `phone`, `active`, `updated_by`, `updated_date`) VALUES (20, 12, NULL, 'cay04', '$2y$10$IdLRvLvzvWTydMWGrT2PEOiO.OGXU7UFJomDOaESA.77MVmdXje9y', 'newan.cathyyagaya@gmail.com', 'Catherine Yagaya', NULL, '', 1, 2, '0000-00-00 00:00:00');
INSERT INTO `user` (`user_id`, `profile_fk`, `employee_id`, `username`, `password`, `email`, `user_name`, `remark`, `phone`, `active`, `updated_by`, `updated_date`) VALUES (21, 12, NULL, 'mre03', '$2y$10$vMx62EYY6SJTVi4T8vm5TuKfqJJ0TFVy3RyndhEjwHNkFODr8kwfq', 'newammonieremolar@gmail.com', 'Monilla Eta', NULL, '', 1, 2, '0000-00-00 00:00:00');
INSERT INTO `user` (`user_id`, `profile_fk`, `employee_id`, `username`, `password`, `email`, `user_name`, `remark`, `phone`, `active`, `updated_by`, `updated_date`) VALUES (22, 12, NULL, 'emc02', '$2y$10$GzMAJVnzr5EjEbRT0Ajxteft2OoMxYRFPTTtsHh6g2GXn6I3lAjLy', 'lareinaelenastore@gmail.com', 'Eleonor Canlas', NULL, '', 1, 2, '0000-00-00 00:00:00');
INSERT INTO `user` (`user_id`, `profile_fk`, `employee_id`, `username`, `password`, `email`, `user_name`, `remark`, `phone`, `active`, `updated_by`, `updated_date`) VALUES (23, 12, NULL, 'ehv05', '$2y$10$RHJjRWfz7sqnvQyYaanosOr7tQ9nwT3iDSe5yPQN3fcvDd.c.IhrO', 'newamemilynvalancio91085@gmail.com', 'Emilyn Valancio', NULL, '', 1, 2, '0000-00-00 00:00:00');


